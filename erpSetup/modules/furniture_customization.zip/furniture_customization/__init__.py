# -*- coding: utf-8 -*-

from PropertyPortal.erpSetup.modules.furniture_customization import models