# -*- coding: utf-8 -*-

from PropertyPortal.erpSetup.modules.furniture_customization.models import product_template
from PropertyPortal.erpSetup.modules.furniture_customization.models import furniture_finish_type
from PropertyPortal.erpSetup.modules.furniture_customization.models import furniture_finish
from PropertyPortal.erpSetup.modules.furniture_customization.models import furniture_product_finish_line